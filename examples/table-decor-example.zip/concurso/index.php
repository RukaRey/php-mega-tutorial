<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "concurso";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if(!isset($_GET['category'])){
        $sql = "SELECT * FROM notas";
    }
    else{
        $sql = "SELECT * FROM notas ORDER BY {$_GET['category']} DESC";
    }
    $result = mysqli_query($conn, $sql);

    $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
    
    mysqli_close($conn);
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidatos</title>
    <link rel="stylesheet" href="css/stylesheet.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Trirong">
</head>
<body>
    <header>
        <img src="img/lemon-slice.png" alt="limon-icon">
        <p><strong><i>limon</i></strong></p>
    </header>

    <div class="table-con">
        <table>
            <tr>
                <th id="id-col"><a href="?category=id"><i>ID</i></a></th>
                <th id="nome-col"><a href="?category=nome_do_candidato"><i>Candidato</i></a></th>
                <th id="nota1-col"><a href="?category=nota_prova_portugues"><i>Nota <br>iPortuguês</i></a></th>
                <th id="nota2-col"><a href="?category=nota_prova_matematica"><i>Nota <br>Matemática</i></a></th>
                <th id="total-col"><a href="?category=nota_total"><i>Total</i></a></th>
            </tr>
        
            <?php 
                foreach($rows as $key){
                    echo "<tr>";
                    echo "<td>" . $key['id'] . "</td>";
                    echo "<td>" . $key['nome_do_candidato'] . "</td>";
                    echo "<td>" . $key['nota_prova_portugues'] . "</td>";
                    echo "<td>" . $key['nota_prova_matematica'] . "</td>";
                    echo "<td>" . $key['nota_total'] . "</td>";
                    echo "</tr>";
                }
            ?>
        </table>
    </div>
</body>
</html>