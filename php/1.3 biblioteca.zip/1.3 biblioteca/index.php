<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "biblioteca";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if(!isset($_GET['category'])){
        $sql = "SELECT * FROM livros";
    }
    else{
        $sql = "SELECT * FROM livros ORDER BY {$_GET['category']} DESC";
    }

    $result = mysqli_query($conn, $sql);

    if(isset($_GET['delete'])){
        $dell = "DELETE FROM `livros` WHERE `livros`.`id` = {$_GET['delete']}";
        mysqli_query($conn, $dell);

        header("Location: index.php");
    }

    $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/stylesheet.css">
    <title>biblioteca</title>
</head>
<body>
    <header>
        <p><b>biblioteca</b></p>
        <form action="index.php">
            <input type="text" name="search">
            <input type="submit" value="Buscar">
        </form>
        <form action="php/insert.php" method='post'>
            <button name='insert'>Inserir novo livro</button>
        </form>
        
        
    </header>
        <div class='biblioteca-livros'>
            <table border="1px">
                <tr>
                    <th><a href="?category=id">Código</a></th>
                    <th><a href="?category=titulo">Título</a></th>
                    <th><a href="?category=autor">Autor</a></th>
                    <th><a href="?category=ano_publicacao">Publicação</a></th>
                    <th><a href="?category=ano_publicacao">Ação</a></th>
                </tr>
                <?php 
                if($rows){
                    foreach($rows as $key){
                        echo "<tr>";
                        echo "<td>" . $key['id'] . "</td>";
                        echo "<td>" . $key['titulo'] . "</td>";
                        echo "<td>" . $key['autor'] . "</td>";
                        echo "<td>" . $key['ano_publicacao'] . "</td>";
                        echo "<td><a href='?delete={$key['id']}'>Excluir</a></td>";
                        echo "</tr>";
                    }
                }else{
                    echo "<td colspan='5'>Nenhum livro registrado!</td>";
                    echo "</tr>";
                }
                    
                ?>
            </table>
        </div>
    
    
</body>
</html>