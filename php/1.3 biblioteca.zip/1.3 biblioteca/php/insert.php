<?php 
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "biblioteca";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/james.css">
</head>
<body>
    <header>
        <div id='bloco1'></div>
        <div id='bloco2'></div>
    </header>

    <div class='new-livro'>
        <form action="insert.php" method='post'>
            <label>Autor</label><br>
            <input type="text" name='autor'><br><br>
            <label>Título</label><br>
            <input type="text" name='titulo'><br><br>
            <label>Ano da publicação</label><br>
            <input type="number" name='ano'><br><br>
            
            <input type="submit" name="insert">
        </form>
    </div>
    
</body>
</html>

<?php 
    if(isset($_POST['insert'])){
        if(!empty($_POST['autor']) && !empty($_POST['titulo']) && !empty($_POST['ano'])){
            $nbook = "INSERT INTO livros(titulo,autor,ano_publicacao) VALUES('{$_POST['titulo']}','{$_POST['autor']}','{$_POST['ano']}')";
            mysqli_query($conn, $nbook);

            header("Location: \.\BANCO-DE-DADOS\\1.3 biblioteca\index.php");
        }
    }

    mysqli_close($conn);
?>