<?php
    #LOGIN
    header("Location: ..\\pessoal\\pages\\main.php")

?>