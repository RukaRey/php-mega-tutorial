<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bem vindo NOME</title>
    <link rel="stylesheet" href="..\css\main.css">
</head>
<body>
    <div class='container'>
        <div id='user-block'>
            <div id='info-user'>
                <img src="..\img\pedrofeliz.jpg" alt="">
                <div>
                    <p id="name">Pedro Nogueira Stephan</p>
                    <p id="subtitle">Garoto de programas</p>    
                </div>
                
            </div>
            <div id="extra-info">
                <div id="desc-user"></div>
                <div id="qual-user"></div>
            </div>
        </div>
        <div class="projects"></div>
    </div>
</body>
</html>