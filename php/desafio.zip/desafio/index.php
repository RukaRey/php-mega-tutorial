<?php 
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "desafio";
    $correto = true;
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    $_SESSION['login']=false;
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    if (isset($_POST['botao'])){
        $usuario= $_POST['user'];
        $senha = $_POST['pass'];
        
        $sql = "SELECT * FROM usuarios WHERE usuario='$usuario'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) $saida[] = $row; 
            if($saida[0]['usuario'] == $usuario && $saida[0]['senha'] == $senha )
            {
                $_SESSION['login']=true;
                $_SESSION['id']=$saida[0]['id'];
                if ($saida[0]['admin']== 0) 
                {
                    header('Location: php/empresa.php');
                }
                else
                {
                    header('Location: php/senai.php');
                }
            }
        }
        else{
            $correto= false;
        }
    }


?>

<!DOCTYPE html>
<html lang="en">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rakkas&family=Wix+Madefor+Text:ital,wght@0,400..800;1,400..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css\stylesheet.css">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <div class= 'estilo'>
        <div class='info-login'><img src="img\logo-senai-removebg-preview.png" alt=""></div>
        <form action="index.php" method="post">
            <label for="user">Usuário</label>
            <input id='boxes' type="text" id="user" name="user" required>
            <br>
            <label for="pass">Senha</label>
            <input id='boxes' type="password" id="pass" name="pass" required>
            <input id='login' type="submit" name="botao" value="Login">
        </form>
    </div>

</body>
</html>
<?php mysqli_close($conn); ?>