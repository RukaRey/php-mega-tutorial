<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rakkas&family=Wix+Madefor+Text:ital,wght@0,400..800;1,400..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="..\css\cadastro.css">
</head>
<body>
    <div class="background"></div> 
    <div class="card" > 
        <h1>Tiquitim Hardware</h1>
        <p align="center">Cadastrar:</p>
        <form action="resultado.php" method="post" height=10px>
            <div class="logo">
                <img src="logo.png" alt="Logo">
            </div>
            <label for="nome">Digite seu nome:</label>
            <input type="text" name="nome" id="nome"> 
            <label for="email">Digite o seu e-mail:</label>
            <input type="email" name="email_usuario" id="email">
            <label for="senha">Digite sua senha:</label>
            <input type="password" name="senha" id="senha"> 
            <br><br>
            <button type="submit" value="Cadastro">Cadastrar</button>
            <br>
            <button type="reset" id="Limpar">Limpar</button> 
        </form>
    </div>
</body>
</html>
