<?php
    session_start();
    if (!$_SESSION['login']){
        header("Location: ../index.php");
        die;
    }
    $indice=$_SESSION['id'];
    $diretorio= 'D:\xampp\\htdocs\\BANCO-DE-DADOS\\desafio\\empresas_docs\\'. $indice.'\\*';
    $arquivos = glob($diretorio);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bem vinda, empresa!</title>
    <link rel="stylesheet" href="..\css\register.css">
</head>
<body>
    <header>
        <img src="..\img\senai2.png" alt="">
    </header>
    <div class='container'>
        <h1>Seus documentos:</h1>
        <div class='doc-lista'>
            <?php foreach ($arquivos as $arquivo) { ?>
                <?php if (is_file($arquivo)) {
                        $nomeArquivo = basename($arquivo);
                }?>
                <div class='doc-empresa'>
                    <img src="..\img\pdf-icon.png" alt="">
                    <a href="exibirpdf.php?name=<?php echo $nomeArquivo;?>"><?php echo $nomeArquivo;?></a>
                </div>
                
            <?php } ?>    
        </div>    
    </div>
    
    
</body>
</html>