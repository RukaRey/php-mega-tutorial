<?php
session_start();
if (!$_SESSION['login']){
    header("Location: ../index.php");
    die;
}
$indice = $_POST['indice'];
echo "<pre>";
print_r ($_FILES['document']);

$diretorio= 'D:\xampp\\htdocs\\BANCO-DE-DADOS\\desafio\\empresas_docs\\'. $indice;
if(!is_dir($diretorio)){
    mkdir($diretorio,0777, true);
}
if ($_FILES['document']['error']==0){
    $diretorio_img= 'D:\xampp\\htdocs\\BANCO-DE-DADOS\\desafio\\empresas_docs\\'. $indice . '\\'. date('d-m-Y-m-i').'.pdf';
    move_uploaded_file($_FILES['document']['tmp_name'],$diretorio_img);
    header("Location: ../php/senai.php");
}
else{
    echo "error:";
}




