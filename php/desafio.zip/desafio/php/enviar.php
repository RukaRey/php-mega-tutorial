<?php 
session_start();
if (!$_SESSION['login']){
        header("Location: ../index.php");
        die;
    } ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/enviar.css">
</head>
<body>
    <header>
        <img src="..\img\senai2.png" alt="">
    </header>
    <div class="container">
        <div class="align">
            <form action="encaminhar.php" id="uploadForm" method="post" enctype="multipart/form-data">
                <label><h1>Anexar Documento</h1><hr> 
                <input id="fileInput" type="file" name="document"></label>
                <div>
                    <input id='block' type="hidden" name='indice' value="<?php echo $_GET['id']; ?>">
                    <img src=".../img/pngtree-3d-file-folder-with-paper-inside-png-image_5017894-removebg-preview.png" alt="">
                </div>
                <div id="meuBotaoContainer">
                    <input type="button" onclick="checkFileSize()" value="Enviar" id="meuBotao">
                </div>
            </form>
        </div>
    </div>
    <script>
function checkFileSize() {
    var fileInput = document.getElementById('fileInput');
    var file = fileInput.files[0];
    var maxSize = 4 * 1024 * 1024; // 4MB
    var allowedExtension = "pdf";

    // Verifica se um arquivo foi selecionado
    if (!file) {
        alert('Por favor, selecione um arquivo.');
        return;
    }

    // Verifica a extensão do arquivo
    var fileName = file.name;
    var fileExtension = fileName.split('.').pop().toLowerCase();
    if (fileExtension !== allowedExtension) {
        alert('A extensão do arquivo deve ser PDF.');
        return;
    }

    // Verifica o tamanho do arquivo
    if (file.size > maxSize) {
        alert('O arquivo é muito grande. Tamanho máximo permitido é de 4MB.');
        return;
    }

    // Se tudo estiver correto, envia o formulário
    document.getElementById('uploadForm').submit();
}
</script>
</body>
</html>