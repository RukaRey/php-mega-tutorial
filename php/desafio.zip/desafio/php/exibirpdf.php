<?php 
    session_start();
    if (!$_SESSION['login']){
        header("Location: ../index.php");
        die;
    }
    $indice=$_SESSION['id'];
    $diretorio= $_GET['name'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }
        embed {
            width: 100%;
            height: 100%;
        }
    </style>
</head>
<body>
    <embed src="../empresas_docs/<?php echo $indice;?>/<?php echo $diretorio;?>" type="application/pdf">
</body>
</html>