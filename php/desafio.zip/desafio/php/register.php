<?php 
    session_start();
    if (!$_SESSION['login']){
        header("Location: ../index.php");
        die;
    }
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "desafio";
    $correto = true;
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    if (isset($_POST["botao"])) {
        $nome = $_POST["usuario"];
        $senha = $_POST["senha"];
        $email = $_POST["email"];

        $verificar = "SELECT * FROM usuarios WHERE usuario= '$nome'";
        $resultado = mysqli_query($conn, $verificar);
        if (mysqli_num_rows($resultado) > 0) {
            $correto= false;
        }
        else{
            $inserir = "INSERT INTO `usuarios`(`usuario`, `email`, `senha`,`admin` ) VALUES ('$nome','$email','$senha', 0)";
            mysqli_query($conn,$inserir);
        }
    
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar empresa</title>
    <link rel="stylesheet" href="..\css\register.css">
</head>
<body>
    <header>
        <img src="..\img\senai2.png" alt="">
    </header>
    <div class='container'>
        
        <div class='register-camp'>
            <div class="top-bar"><p>Cadastro de empresa</p></div>
            <div class="linha"></div>
            <form action="register.php" method="post">
                <label for="nome">Nome da Empresa</label>
                <input type="text" name="usuario" id="nome" required>

                <label for="email">Email</label>
                <input type="email" name="email" id="email" required>

                <label for="senha">Senha</label>
                <input type="text" name="senha"  id="senha" required>

                <input class='thumbnail' id='cadastrar-button' type="submit" name="botao" value="Cadastrar">
            </form>
        </div>
    </div>
    
</body>
</html>
<?php mysqli_close($conn); ?>