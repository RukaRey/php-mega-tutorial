<?php 
    session_start();
    if (!$_SESSION['login']){
        header("Location: ../index.php");
        die;
    }
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "desafio";
    $correto = true;
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $sql = "SELECT * FROM usuarios WHERE admin= 0";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) $saida[] = $row;
    }
    else{
        $correto= false;
    }
?>


<!DOCTYPE html>
<html lang="en">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rakkas&family=Wix+Madefor+Text:ital,wght@0,400..800;1,400..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="..\css\senai.css">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de empresas</title>
</head>
<body>
    <header>
        <img src="..\img\senai2.png" alt="">
    </header>
    <div class='container'>
        <a class="thumbnail" id='cadastrar' href="register.php">Cadastrar</a>
        <table id='nome-empresas'>
            <tr>
                <th>Nome da Empresa</th>
                <th>Email</th>
                <th id='action-area'></th>
            </tr>
            <?php  foreach ($saida as $indice => $conteudo){ ?>
            <tr>
                <td><?php echo $saida[$indice]["usuario"]; ?></td>
                <td><?php echo $saida[$indice]["email"]; ?></td>
                <td class="send-button"> 
                    <div><a href="enviar.php?id=<?php echo $saida[$indice]["id"]; ?>"><img src="..\img\send.png" class="thumbnail" alt="senai"></a></div> 
                </td>
            </tr>
            <?php  } mysqli_close($conn);   ?>
        </table>
    </div>
    
</body>
</html>