<?php   
    session_start();
    if (!($_SESSION["login"])){
        header("Location:php/login.php");
    }
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "estoque";
    if (!isset($_SESSION["pesquisa"])) {
        $_SESSION['pesquisa'] = "";
    }
    $conexao = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conexao) {
        die("Connection failed: " . mysqli_connect_error());
    }
    if (isset($_GET['search'])){
        $_SESSION['pesquisa'] = $_GET["search"];
        if(isset($_GET["order"])){
            $consulta = "SELECT * FROM produtos WHERE nome LIKE '%{$_SESSION['pesquisa']}%' ORDER BY {$_GET["order"]} ASC";
        }
        else{
            $consulta = "SELECT * FROM produtos WHERE nome LIKE '%{$_SESSION['pesquisa']}%'";
        }
    }
    else{
        $consulta = "SELECT * FROM produtos";
    }
    if (isset($_GET['del'])){
        $consulta ="DELETE FROM `produtos` WHERE id= {$_GET['del']}";
        header("Location: index.php");
    }
    $result = mysqli_query($conexao, $consulta);
    if (mysqli_num_rows($result) > 0) { 
        while($row = mysqli_fetch_assoc($result)) {
            $saida[]= $row;
            $notresult=true;
        }
      } else {
        $notresult=false;
      }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Estoque</title>
    <link rel="stylesheet" href="css/james.css">
</head>
<body>
    <header>
        <div id='bloco1'></div>
        <div id='bloco2'></div>
        <a href="index.php"><img id="logo" src="img/SJE.png" alt="img-mercado"></a>
        
        <div id="search-bar">
            <form action="index.php" method="get">
                <input id="search-box" type="text" name="search" placeholder="Pesquisar...">
                <button id="search-button" value="procurar"><img src="img/search.png" alt="seac"></button>
                
            </form>
        </div>
    </header>
    
    <div class='tabela'>
        <table>
            <tr id='titulos'>
                <th><a href="index.php?search=<?php echo $_SESSION['pesquisa'];?>&order=id"><p><i>ID</i></p></a></th>
                <th><a href="index.php?search=<?php echo $_SESSION['pesquisa'];?>&order=nome"><p><i>Produto</i></p></a></th>
                <th><a href="index.php?search=<?php echo $_SESSION['pesquisa'];?>&order=descricao"><p><i>Descrição</i></p></a></th>
                <th><a href="index.php?search=<?php echo $_SESSION['pesquisa'];?>&order=quantidade"><p><i>Quantidade</i></p></a></th>
                <th><a href="index.php?search=<?php echo $_SESSION['pesquisa'];?>&order=preco"><p><i>Preço</i></p></a></th>
                <th><p><i>Ação</i></p></th>
            </tr>
            <?php if($notresult){ foreach ($saida as $indice => $conteudo){?>	
            <tr>
                <td><?php echo $saida[$indice]['id']; ?></td>
                <div class="nome-produto"><td><?php echo $saida[$indice]['nome']; ?></td></div>
                <td><?php echo $saida[$indice]['descricao']; ?></td>
                <td><?php echo $saida[$indice]['quantidade']; ?></td>
                <td><?php echo $saida[$indice]['preco']; ?></td>
                <td><a id='ex-button' href="index.php?del=<?php echo $saida[$indice]['id']; ?>">Excluir</a>
                <a id='ed-button' href="php/edit.php?indice=<?php echo $saida[$indice]['id']; ?>">Editar</a></td>
            </tr>
            <?php }} else{ ?>
                <tr>
                    <td colspan="6"><p>Nenhum item registrado!</p></td>
                </tr>
                
            
            <?php }  mysqli_close($conexao); ?>
            <tr>
                <td colspan="6"><a id='add-button' href="php/insert.php">Adicionar</a></td>
            </tr>
        </table>
        
    </div>
    
</body>
</html>