<?php   
    session_start();
    if (!($_SESSION["login"])){
        header("Location:php/login.php");
    }
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "estoque";
    
    $id = $_GET['indice'];
    
    $conexao = mysqli_connect($servername, $username, $password, $dbname);
    
    $consulta = "SELECT * FROM produtos WHERE id= $id";
    $result = mysqli_query($conexao, $consulta);
    if (mysqli_num_rows($result) > 0) { 
        while($row = mysqli_fetch_assoc($result)) {
            $saida[]= $row;
            $notresult=true;
        }
      } else {
        $notresult=false;
      }
      
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(to bottom, red 50%, blue 50%);
            padding: 10px 20px;
        }

        .header-top, .header-bottom {
            flex: 1;
        }

        img {
            height: 50px;
        }

        .voltar-button {
            background: transparent;
            border: none;
            cursor: pointer;
            position: absolute;
            left: 10px;
            top: 100px;
        }

        main {
            padding: 40px 20px 20px 20px;
        }

        h1 {
            margin-bottom: 200px;
            margin-left: 316px;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
        }

        h1 {
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 8px;
            border: none;
            border-bottom: 1px solid #ccc;
            border-radius: 0;
            outline: none;
        }

        .quantity-input {
            display: flex;
            align-items: center;
        }

        .button-group {
            display: flex;
            justify-content: space-between;
        }

        .save-button, .cancel-button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .save-button {
            background-color: green;
            color: #fff;
        }

        .cancel-button {
            background-color: red;
            color: #fff;
        }
    </style>
</head>

<body>
    <header>
        <div class="header-top"></div>
        <div class="header-bottom"></div>
        <img src="logo.png" alt="Logo">
    </header>
    <button class="voltar-button"><img src="voltar-icon.png" alt="Voltar"></button>
    <main>
        <h1>Editar</h1>
        <form action="save.php" method="post">
            <div class="form-produtos">
                <label for="produto">Produto</label>
                <input type="text" id="produto" name="nome" value="<?php echo $saida[0]['nome'];?>" required>
            </div>
            <div class="form-produtos">
                <label for="descricao">Descrição</label>
                <input type="text" id="descricao" name="descricao" value="<?php echo $saida[0]['descricao'];?>" required>
            </div>
            <div class="form-produtos">
                <label for="quantidade">Quantidade</label>
                <div class="quantity-input">
                    <input type="number" id="quantidade" name="quantidade" value="<?php echo $saida[0]['quantidade'];?>" required>
                </div>
            </div>
            <div class="form-produtos">
                <label for="preco">Preço</label>
                <input type="number" id="preco" name="preco" value="<?php echo $saida[0]['preco'];?>" step="0.01" min="0" required>
            </div>
            <div class="button-grupo">
                <button type="submit" class="save-button">Salvar</button>
                <button type="button" class="cancel-button">Cancelar</button>
            </div>
            <input type="hidden" name="id" value= "<?php echo $saida[0]['id'];?>">
        </form>
    </main>
</body>
</html>
<?php mysqli_close($conexao); ?>