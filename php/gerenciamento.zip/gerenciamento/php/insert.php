<?php 
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "estoque";
    
    $notresult=true;
    $conexao = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conexao) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if(isset($_POST["nome"]) && isset($_POST["descricao"]) && isset($_POST["quantidade"])  && isset($_POST["preco"])) {
        $consulta = "INSERT INTO produtos (nome, descricao, quantidade, preco) VALUES ('{$_POST["nome"]}', '{$_POST["descricao"]}', {$_POST["quantidade"]}, {$_POST["preco"]})";
        mysqli_query($conexao, $consulta);
        header("Location: /./BANCO-DE-DADOS/gerenciamento/index.php");
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="insert.php" method="post">
        <input name="nome" type="text">
        <input name="descricao" type="text">
        <input name="quantidade" type="text">
        <input name="preco" type="text">
        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>
<?php mysqli_close($conexao); ?>