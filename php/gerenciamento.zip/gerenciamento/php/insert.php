<?php 
    session_start();
    if (!($_SESSION["login"])){
        header("Location:php/login.php");
    }
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "estoque";
    
    $notresult=true;
    $conexao = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conexao) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if(isset($_POST["nome"]) && isset($_POST["descricao"]) && isset($_POST["quantidade"])  && isset($_POST["preco"])) {
        $consulta = "INSERT INTO produtos (nome, descricao, quantidade, preco) VALUES ('{$_POST["nome"]}', '{$_POST["descricao"]}', {$_POST["quantidade"]}, {$_POST["preco"]})";
        mysqli_query($conexao, $consulta);
        header("Location: ../index.php");
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserir produtos</title>
    <link rel="stylesheet" href="../css/james.css">
</head>
<body>
    <header>
        <div id='bloco1'></div>
        <div id='bloco2'></div>
        <a href="../index.php"><img id="logo" src="../img/SUPERMERCADO.png" alt="img-mercado"></a>
    </header>
    <form id="tiba" action="insert.php" method="post">
        <div class="insert-table">
            <p><i>Informações do produto:</i></p>
            <br><br>
            <div class="insert-full">
                <div class="insert-l">
                    <label>Nome</label><br>
                    <input name="nome" type="text"><br><br>
                    <label>Descrição</label><br>
                    <input name="descricao" type="text"><br><br>
                </div>
                
                <div class="insert-r">
                    <label>Quantidade</label><br>
                    <input name="quantidade" type="text"><br><br>
                    <label>Preço</label><br>
                    <input name="preco" type="text"><br><br>
                </div>
            </div>
            <input id="insert-button" type="submit" value="Cadastrar">
        </div>
    </form>
</body>
</html>
<?php mysqli_close($conexao); ?>