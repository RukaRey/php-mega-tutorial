<?php   
    session_start();
    $_SESSION['login']=false;
    $notresult=false;
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "estoque";
    
    $conexao = mysqli_connect($servername, $username, $password, $dbname);
    if (isset($_POST["botao"])) {
        $nome= $_POST["usuario"];
        $senha= $_POST["senha"];

        $consulta = "SELECT * FROM usuarios WHERE nome= '$nome' AND senha= '$senha'";

        $result = mysqli_query($conexao, $consulta);
        if (mysqli_num_rows($result) > 0) { 
            $_SESSION['login']=true;
            $notresult=false;
            header("Location: ../index.php");
          } else {
            $notresult=true;
          }
          
    }

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .voltar-button {
            background: transparent;
            border: none;
            cursor: pointer;
            position: absolute;
            left: 10px;
            top: 100px;
        }

        main {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;

            width: 320px;
            height: 520px;
            border-radius: 10px;
            -webkit-box-shadow: 0px 0px 6px -1px #000000; 
            box-shadow: 0px 0px 6px -1px #000000;
            background: #785eef;
        }

        #container .banner {
            width: 1000px;
            height: 1000px;
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
            background: #785eef;

        }

        .login-container {
            max-width: 800px;
            background-color: #f5f5f5;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .logo {
            display: block;
            margin: 0 auto 20px;
            width: 100px; 
        }

        .login-content {
            text-align: center;
        }

        .form-login {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .password-input {
            position: relative;
        }

        .password-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            width: 20px;
            height: 20px;
        }

        .login-button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #4E598C;
            color: #fff;
            cursor: pointer;
        }

        .login-button:hover {
            background-color: darkblue;
        }
    </style>
</head>

<body>
    <main>
        <div class="banner">
            <img src="img/login.png" alt="imagem-login">
            <p style="color: #fff; font-weight: 400;">
                Seja bem vindo ao site de gerenciamento de estoque 
            </p>
        </div>
        <div class="login-container">
            <img src="../img/SJE.png" alt="Logo" class="logo">
            <div class="login-content">
                <h2>Olá,</h2>
                <form action="login.php" method="post">
                    <div class="form-login">
                        <label for="usuario">Usuário</label>
                        <input type="text" id="usuario" name="usuario" required>
                    </div>
                    <div class="form-login">
                        <label for="senha">Senha</label>
                        <div class="password-input">
                            <input type="password" id="senha" name="senha" required>
                            <span class="password-icon"></span>
                            <?php if ($notresult){ ?>
                            <p>Usuário ou senha incorretos</p>
                            <?php } ?>
                        </div>
                    </div>
                    <button type="submit" name="botao" class="login-button">Entrar</button>
                </form>
                <p>Novo usuário? <a href="register.php">Cadastre-se</a></p>
            </div>
        </div>
    </main>
</body>

</html>
<?php mysqli_close($conexao); ?>