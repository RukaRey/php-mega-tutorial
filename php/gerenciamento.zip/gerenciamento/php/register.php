<?php 
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "estoque";
    $result=true;
    $a=0;
    $existe= false;
    $conexao = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conexao) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if(isset($_POST["nome"]) && isset($_POST["senha1"]) && isset($_POST["senha2"])){
        $nome = $_POST["nome"];
        
        
        $verificar = "SELECT * FROM usuarios WHERE nome= '$nome'";

        $usuarios = mysqli_query($conexao, $verificar);
        if (mysqli_num_rows($usuarios) > 0) { 
            while($row = mysqli_fetch_assoc($usuarios)) {
              if ($row["nome"] == $nome) {
                $a++;
              }
            }
          } else {
            $notresult=true;
          }
        if ($a >0) {
            $existe=true;
        }
        if (!$existe) {
            if($_POST["senha1"] == $_POST["senha2"]){
                $consulta = "INSERT INTO usuarios (nome, senha) VALUES ('{$_POST["nome"]}', '{$_POST["senha1"]}')";
                mysqli_query($conexao, $consulta);
   
                header("Location: ../index.php");
            }   
            else{
                $result=false;
            }
        }
        
    }
    
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .voltar-button {
            background: transparent;
            border: none;
            cursor: pointer;
            position: absolute;
            left: 10px;
            top: 100px;
        }

        main {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            max-width: 800px;
            background-color: #f5f5f5;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .logo {
            display: block;
            margin: 0 auto 20px;
            width: 100px; 
        }

        .login-content {
            text-align: center;
        }

        .form-login {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .password-input {
            position: relative;
        }

        .password-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            width: 20px;
            height: 20px;
        }

        .login-button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: blue;
            color: #fff;
            cursor: pointer;
        }

        .login-button:hover {
            background-color: darkblue;
        }
    </style>
</head>

<body>
    <button class="voltar-button"><img src="voltar-icon.png" alt="Voltar"></button>
    <main>
        <div class="login-container">
            <img src="../img/SJE.png" alt="Logo" class="logo">
            <div class="login-content">
                <h2>Bem vindo!</h2>
                <p>Vamos realizar seu cadastro!</p>
                <form action="register.php" method="post">
                    <div class="form-login">
                        <label for="usuario">Usuário</label>
                        <input type="text" id="usuario" name="nome" required>
                    </div>
                    <div class="form-login">
                        <label for="senha">Senha</label>
                        <div class="password-input">
                            <input type="password" id="senha" name="senha1" required>
                            <span class="password-icon"></span>
                        </div>
                        <label for="senha">Confirmar senha</label>
                        <div class="password-input">
                            <input type="password" id="senha" name="senha2" required>
                            <span class="password-icon"></span>
                        </div>
                        <?php if (!$result){ ?>
                        <p>Por favor insira senha iguais!</p>
                        <?php } else if ($existe){ ?>
                        <p>Usuário ja existe!</p>
                        <?php } ?>
                    </div>
                    <button type="submit" class="login-button">Cadastrar</button>
                </form>
                <p>Já cadastrado? <a href="login.php">Entrar</a></p>
            </div>
        </div>
    </main>
</body>
</html>
<?php mysqli_close($conexao); ?>