<?php
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $quantidade = $_POST['quantidade'];
    $preco = $_POST['preco'];

    echo''.$id.''.$nome.''.$descricao;
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "estoque";

    $conexao = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conexao) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $consulta = "UPDATE produtos SET nome='$nome',descricao='$descricao',quantidade= '$quantidade',preco='$preco' WHERE id=$id";
    mysqli_query($conexao, $consulta);
    if (mysqli_query($conexao,$consulta)) {
        header("Location: ../index.php");
    }
    mysqli_close($conexao);
?>