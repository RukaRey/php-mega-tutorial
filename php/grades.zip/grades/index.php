<?php
    session_start();

    if(isset($_POST['login'])){
        if(empty($_POST['user']) || empty($_POST['pass'])){
            $_SESSION['message'] = "Algo deu errado.";
        }
        else if($_POST['user'] == $_SESSION['username'] && $_POST['pass'] == $_SESSION['password']){
            $_SESSION['message'] = "Algo deu certo.";
        }
        else{
            $_SESSION['message'] = "Credenciais incorretas.";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrar</title>
    <link rel="stylesheet" href="css\stylesheet.css">
</head>
<body>
    <div class="container">
       <div class="login-window">
            <img src="img/graduation-hat.png" alt="">
            <p id="info-text">Entrar em sua conta</p>
            <form action="index.php" method="post">
                <label>Nome: </label><br>
                <input type="text" name="user"><br>
                <label>Senha: </label><br>
                <input type="password" name="pass"><br><br>
                <input id="botao" type="submit" name="login" value="   Entrar   "><br><br>
            </form>
            <a id="botao1" href="php/register.php">Não tem conta?</a>
            <?php
                if(isset($_SESSION['message']) && !empty($_SESSION['message'])) {
                    echo $_SESSION['message'];
                    $_SESSION['message'] = "";
                }
            ?>
        </div> 
    </div>

    
    
</body>
</html>

<?php
    if(isset($_POST['login'])){
        if($_POST['user'] == $_SESSION['username'] && $_POST['pass'] == $_SESSION['password']){
            header("Location: php\profile.php", true, 301);
        }
    }
    
?>