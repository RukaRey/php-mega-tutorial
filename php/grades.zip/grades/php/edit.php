<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Editando aluno: <?php  echo $_SESSION['alunos'][$_SESSION['aluno-edit']][0];?></h3><br>
    <form action="edit.php" method='post'>
        <label>Novo nome: </label><br>
        <input type="text" name="nome-aluno" value="<?php echo $_SESSION['alunos'][$_SESSION['aluno-edit']][0];?>"><br><br>

        <label>Nota 1:</label><br>
        <input type="number" name="n1" value="<?php echo $_SESSION['alunos'][$_SESSION['aluno-edit']][1];?>"><br><br>

        <label>Nota 2:</label><br>
        <input type="number" name="n2" value="<?php echo $_SESSION['alunos'][$_SESSION['aluno-edit']][2];?>"><br><br>

        <label>Nota 3:</label><br>
        <input type="number" name="n3" value="<?php echo $_SESSION['alunos'][$_SESSION['aluno-edit']][3];?>"><br><br>

        <label>Nota 4:</label><br>
        <input type="number" name="n4" value="<?php echo $_SESSION['alunos'][$_SESSION['aluno-edit']][4];?>"><br><br>

        <input type="submit" name="ready" value="Atualizar">
    </form>
</body>
</html>


<?php

    if(isset($_POST['ready'])){
        foreach($_SESSION['alunos'] as $aluno => $name){
            if($aluno == $_SESSION['aluno-edit']){
    
                $_SESSION['alunos'][$aluno][0] = $_POST["nome-aluno"];

                $_SESSION['alunos'][$aluno][1] = $_POST["n1"];
                $_SESSION['alunos'][$aluno][2] = $_POST["n2"];
                $_SESSION['alunos'][$aluno][3] = $_POST["n3"];
                $_SESSION['alunos'][$aluno][4] = $_POST["n4"];
    
            }
        }

        header("Location: profile.php");
    }
    

?>