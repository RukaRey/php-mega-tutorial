<?php
    session_start();
    unset($_SESSION['alunos']);
    header("Location: profile.php")

?>