<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Aluno</title>
</head>
<body>
    <header>hearde</header>

    <div class="container">
        <form action="notas.php" method="post">
            <div class="nome">
                <label>Nome do Aluno:</label><br>
                <input type="text" name="aluno-nome">
            </div>

            <div class="notas">
                <p>Adicionar notas</p>
                <label>Primeiro Bimestre:</label><br>
                <input type="number" name="1B"><br><br>
                
                <label>Segundo Bimestre:</label><br>
                <input type="number" name="2B"><br><br>
                
                <label>Terceiro Bimestre:</label><br>
                <input type="number" name="3B"><br><br>
                
                <label>Quarto Bimestre:</label><br>
                <input type="number" name="4B"><br><br>
            </div>

            
            <input type="submit" name="register" value="Registrar aluno">
        </form>
    </div>
    
</body>
</html>

<?php
    session_start();

    function add_aluno($nome, $notas) {
        if (!isset($_SESSION['alunos'])) {
            $_SESSION['alunos'] = [];
        }
        $_SESSION['alunos'][$nome] = $notas;
    }

    if(isset($_POST['register'])){
        if(!empty($_POST['aluno-nome']) && !empty($_POST['1B']) && !empty($_POST['2B']) && !empty($_POST['3B']) && !empty($_POST['4B'])){
            $nome = $_POST['aluno-nome'];
            $notas = [$_POST['1B'], $_POST['2B'], $_POST['3B'], $_POST['4B']];
        }
        
        if(!empty($nome) && !empty($notas)){
            add_aluno($nome, $notas);
            header("Location: profile.php", true, 301);
        }
        else{
            echo "Campos importantes vazios.<br>";
        }
    }
?>