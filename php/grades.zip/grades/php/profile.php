<?php 
    session_start();

    $username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo "Olá professor " . $username . "!"; ?></title>
    <link rel="stylesheet" href="\.\grades\css\dashboard.css">
</head>
<body>
    <header>
        <img src="\.\grades\img\graduation-hat.png" alt="">
        <div class="header-content">
            <a href="\.\grades\index.php"><p>Sair</p></a>
            <a href="\.\grades\index.php"><img src="\.\grades\img\cross.png" alt=""></a>
        </div>
    </header>

    <div class="container">
        <div class="profile">
            <div class="pfp">
                <img src="\.\grades\img\user.png" alt="">

            </div>
            <div class="prof-info">
                <p>Professor <?php echo $username . "."; ?></p>
                <a href="notas.php">Adicionar aluno</a>

            </div>
        </div>
        <br>
        <div class="alunos-tabela">
            notas dos alunos
            <table border="none">
                <tr>
                    <th>Nome</th>
                    <th>1° Bimestre</th>
                    <th>2° Bimestre</th>
                    <th>3° Bimestre</th>
                    <th>4° Bimestre</th>
                    <th>Média</th>
                </tr>
                <?php
                    if (isset($_SESSION['alunos']) && !empty($_SESSION['alunos'])) {
                        foreach ($_SESSION['alunos'] as $nome => $notas) {
                            $media = array_sum($notas) / count($notas);

                            echo "<tr>";
                            echo "<td>$nome</td>";
                            foreach ($notas as $nota) {
                                echo "<td>$nota</td>";
                            }
                            echo "<td>$media</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>Nenhum aluno registrado.</td></tr>";
                    }
                 ?>
            </table>
        </div>
    </div>
    <br>
    
</body>
</html>