<?php 
    session_start();

    if(isset($_SESSION['username']) && !empty($_SESSION['username'])){
        $username = $_SESSION['username'];
    }
    
    // Função para excluir um aluno da tabela
    function excluirAluno($pos) {
        if (isset($_SESSION['alunos']) && !empty($_SESSION['alunos'])) {
            unset($_SESSION['alunos'][$pos]);
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo "Olá professor " . $username . "!"; ?></title>
    <link rel="stylesheet" href="\.\grades\css\new.css">
</head>
<body>
    <header>
        <img src="\.\grades\img\graduation-hat.png" alt="">
        <div class="header-content">
            <a href="\.\grades\index.php"><p>Sair</p></a>
            <a href="\.\grades\index.php"><img src="\.\grades\img\cross.png" alt=""></a>
        </div>
    </header>

    <div class="container">
        <div class="profile">
            <div class="pfp">
                <img src="\.\grades\img\user.png" alt="">
            </div>
            <div class="prof-info">
                <p>Professor <?php echo $username . "."; ?></p>
                <a href="notas.php">Adicionar aluno</a>
            </div>
        </div>
        <br>
        <div class="alunos-tabela">
            <div class="tabela">
                <table border="none">
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>1° Bimestre</th>
                        <th>2° Bimestre</th>
                        <th>3° Bimestre</th>
                        <th>4° Bimestre</th>
                        <th>Média</th>
                        <th>Ação</th>
                    </tr>
                    <?php
                        $count = 0;
                        if (isset($_SESSION['alunos']) && !empty($_SESSION['alunos'])) {
                            foreach ($_SESSION['alunos'] as $pos => $items) {
                                echo "<tr>";
                                echo "<td>$pos</td>";
                                echo "<td>$items[0]</td>";
                                echo "<td>$items[1]</td>";
                                echo "<td>$items[2]</td>";
                                echo "<td>$items[3]</td>";
                                echo "<td>$items[4]</td>";
                                $media = ($items[1] + $items[2] + $items[3] + $items[4])/4;
                                echo "<td>$media</td>";
                                echo "<td><a href='?excluir=$pos'>Excluir</a>
                                        <a href='?editar=$pos'>Editar</a></td>";
                                echo "</tr>";

                            }
                        } else {
                            echo "<tr><td colspan='8'>Nenhum aluno registrado.</td></tr>";
                        }
                    ?>
                </table>
            </div>
        </div>
    </div>
    <br>
</body>
</html>

<?php
    echo $_SESSION['aluno-edit'];
    // Verifica se um aluno foi solicitado para exclusão
    if(isset($_GET['excluir'])){
        $aluno_a_excluir = $_GET['excluir'];
        excluirAluno($aluno_a_excluir);
        // Redireciona para a mesma página após a exclusão
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }
    
    if(isset($_GET['editar'])){
        $_SESSION['aluno-edit'] = $_GET['editar'];

        header("Location: edit.php");
        exit();
    }
?>
