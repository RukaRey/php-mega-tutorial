<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar conta</title>
    <link rel="stylesheet" href="\.\grades\css\stylesheet.css">
</head>
<body>
    <div class="container">

        <div class="login-window">
        <br>
            <img src="\.\grades\img\open-book.png" alt="">
            <p>Criar conta?</p>

            <form action="register.php" method="post">
                <label>Nome: </label><br>
                <input type="text" name="user"><br>
                <label>Senha: </label><br>
                <input type="password" name="pass"><br><br>
                <input id="botao" type="submit" name="register" value="Registrar">
            </form>
        </div>
    </div>
</body>
</html>

<?php
    session_start();

    if (isset($_POST['register'])){
        if(!empty($_POST['user']) && !empty($_POST['pass'])){
            header("Location: \.\grades\index.php", true, 301);
        }
        if(!empty($_POST['user'])){
            $_SESSION['username'] = $_POST['user'];
        }
        if(!empty($_POST['pass'])){
            $_SESSION['password'] = $_POST['pass'];
        }
    }
    

?>