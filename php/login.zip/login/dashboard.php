<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>header com username</header>

    <div class="container">

        <div class="tri">
            <p>conteudo</p>
        </div>


        <div class="gi">
            <p>conteudo2</p>
        </div>

    </div>
    
    <div class="rodape">informação relevante</div>
</body>
</html>

<?php
    if($_SESSION['logged_in']){
        //site
    }
    else{
        $_SESSION['logged_in'] = false;
        header("Location: index.php", true, 301);
    }
?>