<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="container">
        <div class="login-window">
            <img src="img/eye.png" alt="logo-site">
            <h3>Entrar em sua conta  </h3>

            <form action="index.php" method="post">
                <div class="usuario">
                    <label>Usuário</label><br>
                    <input type="text" name="user"><br><br>
                </div>
                
                <div class="senha">
                    <label>Senha</label><br>
                    <input type="password" name="password"><br><br>
                </div>
                
                <input id="botao" type="submit" name="login" value="Entrar">
            </form>
            <br>
            <a id="botao1" href="registro.php">Não tem conta?</a>
        </div>
    </div>
    
    
</body>
</html>

<?php
    session_start();
    // echo $_SESSION['username'] . "<br>" . $_SESSION['password'] . "<br>";

    $_POST['user'] = empty($_POST['user']);
    $_POST['password'] = empty($_POST['password']);

    if(isset($_POST['login'])){
        if(($_SESSION['username'] <> $_POST['user']) || ($_SESSION['password'] <> $_POST['password'])){
            echo "";  
            $_SESSION['logged_in'] = true;

            header("Location: dashboard.php", true, 301);
        }
        else if(!empty($_SESSION['username']) && !empty($_SESSION['password'])){
            echo "";
            
        }
        else if(empty($_POST['user']) || empty($_POST['password'])){
            echo "";
        }
    }
?>