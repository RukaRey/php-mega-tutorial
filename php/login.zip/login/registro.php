<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar conta</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="container">
        <div class="login-window">
            <img src="img/question.png" alt="eye">
            <h3>Criar conta?</h3>

            <form action="registro.php" method="post">
                <label>Usuário</label><br>
                <input type="text" name="user"><br><br>

                <label>Senha</label><br>
                <input type="password" name="password"><br><br>
                <input type="submit" name="login" value="Registrar">
            </form>
        </div>
    </div>
</body>
</html>

<?php
    session_start();


    if (isset($_POST['login'])){
        if(!empty($_POST['user']) && !empty($_POST['password'])){
            header("Location: index.php", true, 301);
        }
        if(!empty($_POST['user'])){
            $_SESSION['username'] = $_POST['user'];
        }
        if(!empty($_POST['password'])){
            $_SESSION['password'] = $_POST['password'];
        }
    }
    

?>